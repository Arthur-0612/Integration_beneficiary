const express = require('express');
const oracledb = require('oracledb');
const cors = require('cors');

const app = express();
const port = 3000;
app.use(express.static('public'));

oracledb.initOracleClient({ libDir: '/opt/oracle/instantclient_19_19' });
app.use(cors());

const dbConfig = {
    user: 'GH_CDS',
    password: 'GH_CDS',
    connectString: 'dbtst1.2066.cloudmv.com.br:1521/tst12066.db2066.mv2066vcn.oraclevcn.com'
};

app.get('/integration1', async (req, res) => {
    let connection;
    try {
        connection = await oracledb.getConnection(dbConfig);
        const pacientes = await findAllPatients(connection);

        if (!pacientes.length) {
            return res.status(404).json({ message: 'Nenhum paciente encontrado' });
        }

        const resultados = [];
        const enviadosComSucesso = [];

        for (const paciente of pacientes) {
            const payload = {
                numeroDocumento: paciente.NR_DOCUMENTO || '',
                numeroCarteira: paciente.NR_CARTEIRA || '',
                nomeCarteira: paciente.NM_TITULAR || '',
                nome: paciente.NM_PACIENTE || '',
                codigoConvenio: paciente.CD_CONVENIO || '',
                codigoPlanoConvenio: paciente.CD_CON_PLA || ''
            };

            try {
                const response = await axios.put(
                    'https://api.globalhealth.mv/health-insurance-store/persons',
                    payload,
                    {
                        headers: {
                            'accept': '*/*',
                            'Content-Type': 'application/json',
                            'x-api-key': ''
                        }
                    }
                );
                const logData = {
                    status: 'enviado',
                    payload,
                    apiResponse: response.data
                };
                console.log('LOG ENVIO SUCESSO:', JSON.stringify(logData, null, 2));
                resultados.push(logData);
                enviadosComSucesso.push(logData);

            } catch (err) {
                const logData = {
                    status: 'erro',
                    payload,
                    error: err.message
                };
                console.error('LOG ENVIO ERRO:', JSON.stringify(logData, null, 2));
                resultados.push(logData);
            }
            await new Promise(resolve => setTimeout(resolve, 2000));
        }
        
        console.log('TODOS OS ENVIOS COM SUCESSO:');
        console.log(JSON.stringify(enviadosComSucesso, null, 2));
        res.json({ status: 'Processo finalizado', total: resultados.length, resultados });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Erro no servidor' });
    } finally {
        if (connection) {
            await connection.close();
        }
    }
});

async function findAllPatients(connection) {
    const sql = `
        SELECT
            p.NR_DOCUMENTO,
            c.NR_CARTEIRA,
            c.NM_TITULAR,
            p.NM_PACIENTE,
            c.CD_CONVENIO,
            c.CD_CON_PLA
        FROM paciente p
        JOIN carteira c ON p.cd_paciente = c.cd_paciente`;

    const result = await connection.execute(sql, [], {
        outFormat: oracledb.OUT_FORMAT_OBJECT
    });

    return result.rows;
}

app.listen(port, () => {
    console.log(`Servidor rodando na porta ${port}`);
});