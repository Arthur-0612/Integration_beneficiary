var globalVariables = {
    token: '',
    clientKey: '',
    language: '',
    inAIframe:
        window.location !== window.parent.location &&
        (params.get("m") || "preview") === "preview",
};


const pdfjsLib = window['pdfjs-dist/build/pdf'];
pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/2.11.338/pdf.worker.min.js';

async function getAttendances() {
    const loading = document.querySelector('.backdrop__container');

    try {
        loading.classList.add('backdrop__container__show');

        const urlParams = new URLSearchParams(window.location.search);
        const documentNumber = urlParams.get('documentNumber') || '';

        const apiUrl = `http://localhost:443/integration3?documentNumber=${encodeURIComponent(documentNumber)}`;

        const response = await fetch(apiUrl, {
            method: 'GET',
            headers: {
                'Authorization': `Bearer ${globalVariables.token}`,
            }
        });

        if (!response.ok) {
            const errorMessage = `Erro ${response.status}: ${response.statusText}`;
            throw new Error(errorMessage);
        }

        const attendanceUrl = await response.json();
        loading.classList.remove('backdrop__container__show');
        renderListView(attendanceUrl);

    } catch (error) {
        loading.classList.remove('backdrop__container__show');
        document.querySelector('#listView').innerHTML = '<span class="text-muted ps-0">Sem registros de atendimentos.</span>';
        console.error('Erro ao buscar atendimentos:', error);
    }
}


function renderListView(items) {
    items.forEach(attendanceItem => {
        const formattedDate = formatDate(attendanceItem.dtAtendimento);

        const bsGridItem = document.createElement('li');
        bsGridItem.className = 'col-12 col-md-6 col-lg-4';

        const card = document.createElement('div');
        card.className = 'card__attendance';

        const title = document.createElement('h5');
        title.className = 'card__attendance__title';
        title.innerHTML = formattedDate;

        const info = document.createElement('div');
        info.className = 'card__attendance__info';
        info.innerHTML = `<img src="assets/svg/Orion_clipboard.svg" class="icon__clipboard"></img> Nº Atend.: ${attendanceItem.cdAtendimento}`;

        card.addEventListener('click', () => openModal(attendanceItem));

        card.appendChild(title);
        card.appendChild(info);
        bsGridItem.appendChild(card);

        listView.appendChild(bsGridItem);
    });
}

let pdfDoc = null;
let currentPage = 1;


async function getDocumentAndPreview(attendanceItem, examType) {
    const loading = document.querySelector('.backdrop__container');

    try {
        loading.classList.add('backdrop__container__show');

        const cdAtendimento = 1788997; //attendanceItem.cdAtendimento;

        const response = await fetch(`http://localhost:443/integration3/mostrar-pdf/${cdAtendimento}/${examType}`, {
            method: 'GET',
            headers: {
                'Authorization': `Bearer ${globalVariables.token}`,
            }
        });

        if (!response.ok) {
            throw new Error('Erro ao buscar documentos');
        }

        loading.classList.remove('backdrop__container__show');

        const canvas = document.getElementById('pdf-canvas');
        const context = canvas.getContext('2d');

        const blob = await response.blob();
        const fileReader = new FileReader();
        fileReader.onload = function () {
            const typedarray = new Uint8Array(this.result);
            pdfjsLib.getDocument(typedarray).promise.then(pdf => {
                pdfDoc = pdf;
                renderPage(currentPage);

                document.getElementById('prevButton').disabled = currentPage === 1;
                document.getElementById('nextButton').disabled = currentPage >= pdfDoc.numPages;
            });
        };
        fileReader.readAsArrayBuffer(blob);

        // let blobUrl = URL.createObjectURL(blob);
        // let downloadButton = document.getElementById('downloadButton');
        //
        // let newButton = downloadButton.cloneNode(true);
        // downloadButton.parentNode.replaceChild(newButton, downloadButton);
        //
        // newButton.href = blobUrl;
        // newButton.download = `${examType}-${new Date().getTime()}.pdf`;
        //
        // newButton.addEventListener('click', () => {
        //     window.open(blobUrl);
        // });

        document.getElementById('prevButton').onclick = () => {
            if (currentPage > 1) {
                currentPage--;
                renderPage(currentPage);
            }
        };

        document.getElementById('nextButton').onclick = () => {
            if (currentPage < pdfDoc.numPages) {
                currentPage++;
                renderPage(currentPage);
            }
        };

    } catch (error) {
        loading.classList.remove('backdrop__container__show');
        console.error('Erro ao buscar documentos:', error);
        showError();
    }
}

function renderPage(pageNum) {
    pdfDoc.getPage(pageNum).then(page => {
        const viewport = page.getViewport({ scale: 1.5 });
        const canvas = document.getElementById('pdf-canvas');
        const context = canvas.getContext('2d');
        canvas.height = viewport.height;
        canvas.width = viewport.width;

        const renderContext = {
            canvasContext: context,
            viewport: viewport
        };
        page.render(renderContext);

        document.getElementById('prevButton').disabled = pageNum === 1;
        document.getElementById('nextButton').disabled = pageNum >= pdfDoc.numPages;
    });
}


function openModal(attendanceItem) {
    let modalShowDocuments = document.createElement('div');
    const viewExamsPath = 'views/shared/shared-modal.html';

    fetch(viewExamsPath)
        .then((response) => response.text())
        .then((html) => {
            modalShowDocuments.innerHTML = html;
            document.body.appendChild(modalShowDocuments);

            const rowDocumentTypes = modalShowDocuments.querySelector('.row__documentTypes');
            let activeButton = null;
            let firstBuntton;

            if (rowDocumentTypes) {
                if (attendanceItem.receita) {
                    const receitaDiv = document.createElement('div');
                    receitaDiv.className = 'procedure__item';
                    const receitaButton = document.createElement('button');
                    receitaButton.innerText = 'Receita';
                    receitaButton.classList.add('btn__showDoc');
                    receitaButton.addEventListener('click', () => {
                        if (activeButton) {
                            activeButton.style.borderBottom = '';
                            activeButton.classList.remove('active');
                        }

                        receitaButton.style.borderBottom = '2px solid #007bff';
                        activeButton = receitaButton;

                        currentPage = 1;
                        getDocumentAndPreview(attendanceItem, 'receita');
                    });
                    receitaDiv.appendChild(receitaButton);
                    rowDocumentTypes.appendChild(receitaDiv);
                    firstBuntton = firstBuntton || receitaButton;
                }
                if (attendanceItem.atestado) {
                    const atestadoDiv = document.createElement('div');
                    atestadoDiv.className = 'procedure__item';
                    const atestadoButton = document.createElement('button');
                    atestadoButton.innerText = 'Atestado';
                    atestadoButton.classList.add('btn__showDoc');
                    atestadoButton.addEventListener('click', () => {
                        if (activeButton) {
                            activeButton.style.borderBottom = '';
                            activeButton.classList.remove('active');
                        }
                        atestadoButton.style.borderBottom = '2px solid #007bff';
                        activeButton = atestadoButton;

                        currentPage = 1;
                        getDocumentAndPreview(attendanceItem, 'atestado');
                    });
                    atestadoDiv.appendChild(atestadoButton);
                    rowDocumentTypes.appendChild(atestadoDiv);
                    firstBuntton = firstBuntton || atestadoButton;
                }
                if (attendanceItem.exame) {
                    const exameDiv = document.createElement('div');
                    exameDiv.className = 'procedure__item';
                    const exameButton = document.createElement('button');
                    exameButton.innerText = 'Exame';
                    exameButton.classList.add('btn__showDoc');
                    exameButton.addEventListener('click', () => {
                        if (activeButton) {
                            activeButton.style.borderBottom = '';
                            activeButton.classList.remove('active');
                        }
                        exameButton.style.borderBottom = '2px solid #007bff';
                        activeButton = exameButton;

                        currentPage = 1;
                        getDocumentAndPreview(attendanceItem, 'exame');
                    });
                    exameDiv.appendChild(exameButton);
                    rowDocumentTypes.appendChild(exameDiv);
                    firstBuntton = firstBuntton || exameButton;
                }
                if (attendanceItem.encaminhamento) {
                    const encaminhamentoDiv = document.createElement('div');
                    encaminhamentoDiv.className = 'procedure__item';
                    const encaminhamentoButton = document.createElement('button');
                    encaminhamentoButton.innerText = 'Encaminhamento';
                    encaminhamentoButton.classList.add('btn__showDoc');
                    encaminhamentoButton.addEventListener('click', () => {
                        if (activeButton) {
                            activeButton.style.borderBottom = '';
                            activeButton.classList.remove('active');
                        }
                        encaminhamentoButton.style.borderBottom = '2px solid #007bff';
                        activeButton = encaminhamentoButton;

                        currentPage = 1;
                        getDocumentAndPreview(attendanceItem, 'encaminhamento');
                    });
                    encaminhamentoDiv.appendChild(encaminhamentoButton);
                    rowDocumentTypes.appendChild(encaminhamentoDiv);
                    firstBuntton = firstBuntton || encaminhamentoButton;
                }
                if (attendanceItem.relatorio) {
                    const relatorioDiv = document.createElement('div');
                    relatorioDiv.className = 'procedure__item';
                    const relatorioButton = document.createElement('button');
                    relatorioButton.innerText = 'Relatório';
                    relatorioButton.classList.add('btn__showDoc');
                    relatorioButton.addEventListener('click', () => {
                        if (activeButton) {
                            activeButton.style.borderBottom = '';
                            activeButton.classList.remove('active');
                        }
                        relatorioButton.style.borderBottom = '2px solid #007bff';
                        activeButton = relatorioButton;

                        currentPage = 1;
                        getDocumentAndPreview(attendanceItem, 'relatorio');
                    });
                    relatorioDiv.appendChild(relatorioButton);
                    rowDocumentTypes.appendChild(relatorioDiv);
                    firstBuntton = firstBuntton || relatorioButton;
                }
            }

            const modalElement = document.getElementById('pdfModal');
            const modal = new bootstrap.Modal(modalElement);
            modal.show();
            firstBuntton.click();
            modalElement.addEventListener('hidden.bs.modal', () => {
                document.body.removeChild(modalShowDocuments);
            });
        })
        .catch(error => console.error('Erro ao carregar o modal:', error));
}

function formatDate(dateString) {
    const date = new Date(dateString);

    if (isNaN(date.getTime())) {
        return '-'
    }

    const day = String(date.getDate()).padStart(2, '0');
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const year = String(date.getFullYear()).slice(-2);
    const hours = String(date.getHours()).padStart(2, '0');
    const minutes = String(date.getMinutes()).padStart(2, '0');

    return `${day}/${month}/${year} - ${hours}:${minutes}`;
}

function showError() {
    let modalShowDocuments = document.createElement('div');
    const viewExamsPath = 'views/shared/toast-error.html';

    fetch(viewExamsPath)
        .then((response) => response.text())
        .then((html) => {
            modalShowDocuments.innerHTML = html;
            document.body.appendChild(modalShowDocuments);

            let toastEl = modalShowDocuments.querySelector('#errorToast');
            let toast = new bootstrap.Toast(toastEl);

            toastEl.addEventListener('hidden.bs.toast', function () {
                document.body.removeChild(modalShowDocuments)
            });

            toast.show();
        });
}

function clearDownloadButton(downloadButton) {
    downloadButton.href = '';
    downloadButton.download = '';

    const clone = downloadButton.cloneNode(true);
    downloadButton.parentNode.replaceChild(clone, downloadButton);
}

function initTokenConfig() {
    if (!!window.Personal) {
        globalVariables.token = window.Personal.getToken('anyParam');
        localStorage.setItem("auth", globalVariables.token);
        getAttendances();
    }

    window.setConfig = function (token) {
        if (token) {
            globalVariables.token = token;
            localStorage.setItem("auth", globalVariables.token);
            getAttendances();
        }
    }
}
